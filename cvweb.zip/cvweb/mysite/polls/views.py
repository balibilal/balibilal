from django.shortcuts import render, redirect

from .form import *
from .models import Cvform

def viewr(request):
    if request.method == 'POST':
        form = Resume(request.POST, request.FILES)

        if form.is_valid():
            form.save()
            #data=Resume.objects.all()
            #return render(request,'viewCv.html',{'data':data})
    else:
        form = Resume()
    return render(request, 'form.html', {'form' : form})

def index(request):
    return render(request, 'index.html')
def form(request):
    return render(request, 'form.html')

def viewCv(request):
    data=Cvform.objects.all()

    return render(request, 'viewCv.html',{'data':data})

def reglogin(request):
    return render(request, 'reglogin.html')

def datatable(request):
    data=Cvform.objects.all()

    all_Cvform = Cvform.objects.all()
    Cvform.objects.filter(id = 4)


    return render(request, 'datatable.html',{'data':data, 'all_Cvform': all_Cvform})
