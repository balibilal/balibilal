import email
from django.db import models

# Create your models here.
class Cvform(models.Model):

    image = models.ImageField(upload_to='images')
    name = models.CharField(max_length=50)
    email = models.EmailField(max_length=40)
    contact = models.IntegerField()
    cnic = models.IntegerField()
    age = models.IntegerField()
    address = models.CharField(max_length=50)
    description = models.CharField(max_length=100)
