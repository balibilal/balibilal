from django.contrib import admin
from .models import Cvform
# Register your models here.
admin.site.register(Cvform)