from importlib.resources import path
from django.urls import path
from . import views

urlpatterns = [
    path("",views.index, name='index'),
    path("form/",views.viewr, name='form'),
    path("viewCv/",views.viewCv, name='viewCv'),
    path("reglogin/",views.reglogin, name='reglogin'),
    path("datatable/",views.datatable, name='datatable'),
    
]