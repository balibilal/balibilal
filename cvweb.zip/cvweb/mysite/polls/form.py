from django.forms import ModelForm
from .models import *
  
class Resume(ModelForm):
  
    class Meta:
        model = Cvform
        fields = ['image','name', 'email', 'contact', 'cnic', 'age', 'address', 'description']


